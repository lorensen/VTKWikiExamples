#include <vtkSmartPointer.h>
#include <vtkTryDowncast.h>

int main(int, char *[])
{
  // Demonstrate a check of a cast
  return EXIT_SUCCESS;
}
